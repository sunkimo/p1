<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>sensor.php</title>
</head>
<body>
<?php

// 建立MySQL的資料庫連接
$link = mysqli_connect("localhost", "sunkimo", "123456") 
        or die("無法開啟MySQL資料庫連接!<br/>");
mysqli_select_db($link, "sunkimo");  // 選擇myschool資料庫
// 設定SQL查詢字串
$sql = "SELECT * FROM sensor";
//送出UTF8編碼的MySQL指令
mysqli_query($link, 'SET NAMES utf8'); 



$records_per_page = 5;  // 每一頁顯示的記錄筆數
// 取得URL參數的頁數
if (isset($_GET["Pages"])) $pages = $_GET["Pages"];
else                       $pages = 1;

// 執行SQL查詢
$result = mysqli_query($link, $sql);
$total_fields=mysqli_num_fields($result); // 取得欄位數
$total_records=mysqli_num_rows($result);  // 取得記錄數
// 計算總頁數
$total_pages = ceil($total_records/$records_per_page);
// 計算這一頁第1筆記錄的位置
$offset = ($pages - 1)*$records_per_page;
mysqli_data_seek($result, $offset); // 移到此記錄

echo "<h1><center>感測器資料表</center></h1><br/><br/>";
echo "總數: $total_records 筆<br/>";
echo "<table border=1><tr>";
while ( $meta=mysqli_fetch_field($result) )
   echo "<td>".$meta->name."</td>";
echo "</tr>";
$j = 1;
while ($rows = mysqli_fetch_array($result, MYSQLI_NUM)
       and $j <= $records_per_page) {
   echo "<tr>";
   for ( $i = 0; $i<= $total_fields-1; $i++ )
      echo "<td>".$rows[$i]."</td>";
   echo "</tr>";
   $j++;
}
echo "</table><br>";
if ( $pages > 1 )  // 顯示上一頁
   echo "<a href='sensor.php?Pages=".($pages-1).
        "'>上一頁</a>| ";
for ( $i = 1; $i <= $total_pages; $i++ )
   if ($i != $pages)
     echo "<a href=\"sensor.php?Pages=".$i."\">".
          $i."</a> ";
   else
     echo $i." ";
if ( $pages < $total_pages )  // 顯示下一頁
   echo "|<a href='sensor.php?Pages=".($pages+1).
        "'>下一頁</a> ";
mysqli_free_result($result);  // 釋放佔用的記憶體


mysqli_close($link); // 關閉資料庫連接
?>
</body>
</html>
