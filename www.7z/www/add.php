<?php

session_start();  // 啟用交談期
if (!isset($_SESSION["login_session"]) || @$_SESSION["login_session"] == false) 
{
	echo '尚未登入!';
    echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	exit();
}

?>



<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
	<title>add.php</title>
	<link rel=stylesheet type="text/css" href=style5.css>
	
</head>

<body>
<div id="header">
	<p><h1 class="title_top"> 通報系統 </h1></p>
</div>
<div id="nav">
	<table style="display:inline;float:left;">
	<tbody class="menu">
		<tr>
		<td>登入者：<?php echo $_SESSION["ss_username"] ?>&nbsp; &nbsp; &nbsp;</td>
		<td><a class="nav_a" href="main.php">[返回]</a>&nbsp;</td>
		
		</tr>
	</tbody>
	</table>
        
	<table style="display:inline;float:right;">
	<tbody class="menu">
		<tr><td><a class="nav_a" href="logout.php">[登出]</a>&nbsp;</td></tr>
	</tbody>
	</table>
</div>
 

<div id="content">
</br></br>


<form action="action.php" method="post">

<div align="center" display="inline">
<table align="center">
  <tr><td>姓名:</td>
  <td><input type="text" size="10" maxlength="10" autofocus="autofocus" name="name" required />
  </td></tr>
  
  <tr><td>身分證:</td>
  <td><input type="text" size="10" maxlength="10" name="id" required/>
  </td></tr>
  
  <tr><td>住址:</td>
  <td><input type="text" size="60" maxlength="60" name="address" required/>
  </td></tr>
  
  <tr><td>RFID號碼：</td>
  <td><input type="text" size="8" maxlength="8" name="rfid_no" required/>
  </td></tr>
  
  <tr><td>通報狀態：</td>
  <td><input type="radio" value="1" name="state"/>有<input type="radio" value="0" name="state" checked/>無
  </td></tr>
  
  <tr><td>聯絡人:</td>
  <td><input type="text" size="10" maxlength="10" name="rname" required/>
  </td></tr>
  
  <tr><td>聯絡人市話:</td>
  <td><input type="text" size="10" maxlength="10" name="telephone" required/>
  </td></tr>
  
  <tr><td>聯絡人電話:</td>
  <td><input type="text" size="10" maxlength="10" name="mphone" required/>
  </td></tr>
  
  <tr><td>line token:</td>
  <td><input type="text" size="50" maxlength="50" name="rlinetoken" required/>
  </td></tr>
  
  
  
</table>
</div>
</br>
<input type="submit" name="add" value="確定"/>


</form>




</br></br>   
</div>

<div  id="footer"> version : 1.0 </div>
</body>
</html>
