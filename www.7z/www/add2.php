<?php

session_start();  // 啟用交談期
if (!isset($_SESSION["login_session"]) || @$_SESSION["login_session"] == false ) 
{
	echo '<center><font color="red">無權限!</font></center>';
    echo '<meta http-equiv=REFRESH CONTENT=2;url=login.php>';
	exit();
	//header("Location: login.php");
}
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
	<title>fix.php</title>
	<link rel=stylesheet type="text/css" href=style5.css>
	
</head>

<body>
<div id="header">
	<p><h1 class="title_top"> 通報系統 </h1></p>
</div>
<div id="nav">
	<table style="display:inline;float:left;">
	<tbody class="menu">
		<tr>
		<td>登入者：<?php echo $_SESSION["ss_username"] ?>&nbsp; &nbsp; &nbsp;</td>
		<td><a class="nav_a" href="main.php">[返回]</a>&nbsp;</td>
		</tr>
	</tbody>
	</table>
        
	<table style="display:inline;float:right;">
	<tbody class="menu">
		<tr><td><a class="nav_a" href="logout.php">[登出]</a>&nbsp;</td></tr>
	</tbody>
	</table>
</div>
 

<div id="content">
</br></br>


<form action="action.php" method="post">

<div align="center" display="inline">
<table align="center">
  
  <tr><td>感測器名稱:</td>
  <td><input type="text" size="10" maxlength="10" autofocus="autofocus" name="sensorID"  required />
  </td></tr>
  
  <tr><td>GPS位置:</td>
  <td><input type="text" size="50" maxlength="50" name="location" required/>
  </td></tr>
  
  <tr><td>地址:</td>
  <td><input type="text" size="60" maxlength="60" name="sn_address" required/>
  </td></tr>
  
  

 
  
  
</table>
</div>
</br>
<input type="submit" name="add2" value="確定"/>


</form>




</br></br>   
</div>

<div  id="footer"> version : 1.0 </div>
</body>
</html>
