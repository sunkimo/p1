<?php
session_start();  // 啟用交談期

//*********************** TOP 檢查是否已登入********************************************
if (!isset($_SESSION["login_session"]) || @$_SESSION["login_session"] == false) 
{
	echo '<center><font color="red">尚未登入!</font></center>';
    echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	exit();
}
//*********************** END 檢查是否已登入********************************************





//***************************** TOP 連接資料庫 *****************************************
$link = mysqli_connect("localhost", "sunkimo", "123456") or die("無法開啟MySQL資料庫連接!<br/>");
mysqli_select_db($link, "sunkimo");  // 選擇myschool資料庫
mysqli_query($link, 'SET NAMES utf8'); //送出UTF8編碼的MySQL指令
//***************************** END 連接資料庫 *****************************************



//***************************** TOP 刪除功能-預先排除不能做的動作 **********************

if ( isset($_GET["del"]))
{
	$sql="delete from people where p_num='".$_GET["del"]."'";
	
	

	if(@mysqli_query($link, $sql))
	{
		echo '<center><font color="red">刪除成功</font></center>';
	}
	else
	{
		echo '<center><font color="red">刪除失敗</font></center>';
	}
	echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
	require_once("myschool_close.inc");
	exit();
}

//--------------------------------------------------------------

if ( isset($_GET["del2"]))
{
	$sql="delete from sensor where sn_num='".$_GET["del2"]."'";
	
	

	if(@mysqli_query($link, $sql))
	{
		echo '<center><font color="red">刪除成功</font></center>';
	}
	else
	{
		echo '<center><font color="red">刪除失敗</font></center>';
	}
	echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
	require_once("myschool_close.inc");
	exit();
}

//***************************** END 刪除功能-預先排除不能做的動作 **********************




//***************************** TOP 把傳入的字串，去除前後的空白 ***********************
$source = $_POST;
foreach ($source as $key => $value) { $source[$key] = trim($value); }  //把傳入的字串，去除前後的空白。

//***************************** TOP 把傳入的字串，去除前後的空白 ***********************




//***********************************  TOP 新增功能  ***********************************

if(isset($_POST["add"]))
{
	$sql = "SELECT id,rfid_no,rlinetoken FROM people";
	mysqli_query($link, 'SET NAMES utf8'); 
	$result = mysqli_query($link, $sql);


	while($rows = mysqli_fetch_array($result, MYSQLI_BOTH))
	{
		if($_POST["id"] == $rows["id"])
		{
			echo '身分證號碼已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add.php>';
			exit();
		}
		if($_POST["rfid_no"] == $rows["rfid_no"])
		{
			echo 'rfid_no已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add.php>';
			exit();
		}
		if($_POST["rlinetoken"] == $rows["rlinetoken"])
		{
			echo 'rlinetoken已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add.php>';
			exit();
		}
	
	}

	$sql ="insert into people (name,id,address,rfid_no,state,rname,telephone,mphone,rlinetoken) values ('";
	$sql .=$source["name"]."','".$source["id"]."','".$source["address"]."','".$source["rfid_no"]."','";
	$sql .=$source["state"]."','".$source["rname"]."','".$source["telephone"]."','".$source["mphone"]."','".$source["rlinetoken"]."')";

	mysqli_query($link,$sql);
	mysqli_free_result($result);  // 釋放佔用的記憶體
	require_once("myschool_close.inc");

	echo '已新增完成';
	echo '<meta http-equiv=REFRESH CONTENT=1;url=add.php>';
	exit();
}

//----------------------------------------------------------------------------------------------------

if(isset($_POST["add2"]))
{
	$sql = "SELECT sensorID,location,sn_address FROM sensor";
	mysqli_query($link, 'SET NAMES utf8'); 
	$result = mysqli_query($link, $sql);


	while($rows = mysqli_fetch_array($result, MYSQLI_BOTH))
	{
		if($_POST["sensorID"] == $rows["sensorID"])
		{
			echo '感測器名稱已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add2.php>';
			exit();
		}
		if($_POST["location"] == $rows["location"])
		{
			echo 'GPS位置 已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add2.php>';
			exit();
		}
		if($_POST["sn_address"] == $rows["sn_address"])
		{
			echo '地址 已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=add2.php>';
			exit();
		}
	
	}

	$sql ="insert into sensor (sensorID,location,sn_address) values ('";
	$sql .=$source["sensorID"]."','".$source["location"]."','".$source["sn_address"]."')";

	mysqli_query($link,$sql);
	mysqli_free_result($result);  // 釋放佔用的記憶體
	require_once("myschool_close.inc");

	echo '已新增完成';
	echo '<meta http-equiv=REFRESH CONTENT=1;url=add2.php>';
	exit();
}




//***********************************  END 新增功能  ***********************************	
	



//***********************************  TOP 修改功能  ***********************************
if(  isset($_POST["update"])  )
{
	
	$sql2 = "SELECT id,rfid_no,rlinetoken FROM people where p_num <> '".$source["p_num"]."'";
	mysqli_query($link, 'SET NAMES utf8'); 
	$result2 = mysqli_query($link, $sql2);


	while($rows2 = mysqli_fetch_array($result2, MYSQLI_BOTH))
	{
		if($_POST["id"] == $rows2["id"])
		{
			echo '使用者ID已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
		if($_POST["rfid_no"] == $rows2["rfid_no"])
		{
			echo 'rfid_no已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
		if($_POST["rlinetoken"] == $rows2["rlinetoken"])
		{
			echo 'rlinetoken已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
	
	}




	$action='已更新完成';	
	$sql ="update people set ";
	foreach($source as $key => $value)
	{	
		if( !($key=="update") )
		$sql .= $key."='".$value."' ,";
	}
	$sql=substr($sql,0,(strlen($sql)-1));
	$sql .= "where p_num='".$source["p_num"]."'";
}


//----------------------------------------------------------------------

if(  isset($_POST["update2"])  )
{
	
	$sql2 = "SELECT sensorID,location,sn_address FROM sensor where sn_num <> '".$source["sn_num"]."'";
	mysqli_query($link, 'SET NAMES utf8'); 
	$result2 = mysqli_query($link, $sql2);


	while($rows2 = mysqli_fetch_array($result2, MYSQLI_BOTH))
	{
		if($_POST["sensorID"] == $rows2["sensorID"])
		{
			echo '感測器名稱已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
		if($_POST["location"] == $rows2["location"])
		{
			echo 'GPS位置 已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
		if($_POST["sn_address"] == $rows2["sn_address"])
		{
			echo '地址 已有人使用';
			echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
			exit();
		}
	
	}




	$action='已更新完成';	
	$sql ="update sensor set ";
	foreach($source as $key => $value)
	{	
		if( !($key=="update2") )
		$sql .= $key."='".$value."' ,";
	}
	$sql=substr($sql,0,(strlen($sql)-1));
	$sql .= "where sn_num='".$source["sn_num"]."'";
}











//***********************************  END 修改功能  ***********************************



//******************************  TOP 新增與修改共用區  ********************************

	


if(@mysqli_query($link,$sql))
{	
	//假如是修改本身資料，而且成功的話，才需即時修正(視窗左上的登入者名稱)。
	//使用創建一個變數$_SESSION["ss_name"]傳回main.php去修正。
	if(isset($_POST["update"]) && $_SESSION["ss_sno"]==$source["sno"])  
		$_SESSION["new_ss_name"]=$source["name"];
}
else
{
	echo '<center><font color="blue">失敗</font></center>';
}

echo '<center><font color="blue">'.$action.'</font></center>';
require_once("myschool_close.inc");
echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
exit();

//******************************  END 新增與修改共用區  ********************************

?>

