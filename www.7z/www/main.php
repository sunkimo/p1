<?php

session_start();  // 啟用交談期
if (!isset($_SESSION["login_session"]) || @$_SESSION["login_session"] == false ) 
{
	echo '無權限!';
    echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	exit();
	//header("Location: login.php");
	
}
?>



<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
	<title>login.php</title>
	<link rel=stylesheet type=text/css href=style5.css>
</head>

<body>
<div id="header">
	<p><h1 class="title_top"> 通報系統 </h1></p>
</div>
<div id="nav">
	<table style="display:inline;float:left;">
	<tbody class="menu">
		<tr>
		<td>登入者：<?php echo $_SESSION["ss_username"] ?>&nbsp; &nbsp; &nbsp;</td>
			
		</tr>
	</tbody>
	</table>
        
	<table style="display:inline;float:right;">
	<tbody class="menu">
		<tr><td><a class="nav_a" href="logout.php">[登出]</a>&nbsp;</td></tr>
	</tbody>
	</table>
</div>
 

<div id="content">
</br></br>

<?php
	$records_per_page = 5;  // 每一頁顯示的記錄筆數
	// 取得URL參數的頁數
	if(isset($_GET["Pages"]))
		$pages = $_GET["Pages"];
	else	$pages = 1;
	require_once("myschool_open.inc");
	// 執行SQL查詢
	$result = mysqli_query($link, $sql);
	$total_fields=mysqli_num_fields($result); // 取得欄位數
	$total_records=mysqli_num_rows($result);  // 取得記錄數
	// 計算總頁數
	$total_pages = ceil($total_records/$records_per_page);
	// 計算這一頁第1筆記錄的位置
	$offset = ($pages - 1)*$records_per_page;
	mysqli_data_seek($result, $offset); // 移到此記錄
	echo "註冊記錄總數:". $total_records." 筆<br/><br/>";
	echo "<a href=add.php>新增</a>";
	echo "<table class=menu border=1 align=center border-collapse=collapse cellspacing=0 cellpadding=2><tr>";
	while($meta=mysqli_fetch_field($result))
		echo "<td bgcolor=royalblue align=center>".$meta->name."</td>";
	
	echo "</tr>";
	$j = 1;
	while($rows = mysqli_fetch_array($result, MYSQLI_BOTH)	and $j <= $records_per_page)
	{
		echo "<tr>";
		for( $i = 0; $i<= $total_fields-1; $i++ )
		echo "<td>".$rows[$i]."</td>";
		echo "<td bgcolor=yellow align=center>";
		echo "<a href=fix.php?p_num=".$rows["p_num"].">修改</a>";
		
		//echo "<td bgcolor=yellow align=center>";
		//			echo "<a href=fix.php?id=".$rows["sno"].">修改</a>";
					echo "</td>";
					echo "<td bgcolor=yellow align=center>";
					echo "<a href=action.php?del=".$rows["p_num"].">刪除</a>";
		//			echo "</td>";
		
		echo "</td>";
		
		echo "</tr>";
		$j++;
	}
	echo "</table><br>";

	if($pages > 1)  // 顯示上一頁
	echo "<a href='main.php?Pages=".($pages-1)."&Pages2=".$_GET["Pages2"]."'>上一頁</a>| ";
	
	for($i = 1; $i <= $total_pages; $i++)
	{	if ($i != $pages)
			echo "<a href=\"main.php?Pages=".$i."\">".$i."</a> ";
		else
			echo $i." ";
	}
	if( $pages < $total_pages )  // 顯示下一頁
		echo "|<a href='main.php?Pages=".($pages+1)."&Pages2=".$_GET["Pages2"]."'>下一頁</a> ";
	mysqli_free_result($result);  // 釋放佔用的記憶體
	//require_once("myschool_close.inc");
?>
</br></br>   
</div>

<div id="content">
</br></br>

<?php
	$records_per_page2 = 5;  // 每一頁顯示的記錄筆數
	// 取得URL參數的頁數
	if(isset($_GET["Pages2"]))
		$pages2 = $_GET["Pages2"];
	else	$pages2 = 1;
	$sql2 = "SELECT * FROM sensor";
	// 執行SQL查詢
	$result2 = mysqli_query($link, $sql2);
	$total_fields2=mysqli_num_fields($result2); // 取得欄位數
	$total_records2=mysqli_num_rows($result2);  // 取得記錄數
	// 計算總頁數
	$total_pages2 = ceil($total_records2/$records_per_page2);
	// 計算這一頁第1筆記錄的位置
	$offset2 = ($pages2 - 1)*$records_per_page2;
	mysqli_data_seek($result2, $offset2); // 移到此記錄
	echo "感測模組紀錄總數: ".$total_records2." 筆<br/><br/>";
	echo "<a href=add2.php>新增</a>";
	echo "<table class=menu border=1 align=center border-collapse=collapse cellspacing=0 cellpadding=2><tr>";
	while($meta2=mysqli_fetch_field($result2))
		echo "<td bgcolor=royalblue align=center>".$meta2->name."</td>";

	echo "</tr>";
	$j = 1;
	while($rows2 = mysqli_fetch_array($result2, MYSQLI_BOTH)	and $j <= $records_per_page2)
	{
		echo "<tr>";
		for( $i = 0; $i<= $total_fields2-1; $i++ )
		echo "<td>".$rows2[$i]."</td>";
		echo "<td bgcolor=yellow align=center>";
		echo "<a href=fix2.php?sn_num=".$rows2["sn_num"].">修改</a>";
		
		
					echo "</td>";
					echo "<td bgcolor=yellow align=center>";
					echo "<a href=action.php?del2=".$rows2["sn_num"].">刪除</a>";
		
		
		echo "</td>";
		
		echo "</tr>";
		$j++;
	}
	echo "</table><br>";

	if($pages2 > 1)  // 顯示上一頁
	echo "<a href='main.php?Pages2=".($pages2-1)."&Pages1=".$_GET["Pages1"]."'>上一頁</a>| ";
	
	for($i = 1; $i <= $total_pages2; $i++)
	{	if ($i != $pages2)
			echo "<a href=\"main.php?Pages2=".$i."\">".$i."</a> ";
		else
			echo $i." ";
	}
	if( $pages2 < $total_pages2 )  // 顯示下一頁
		echo "|<a href='main.php?Pages2=".($pages2+1)."&Pages1=".$_GET["Pages1"]."'>下一頁</a> ";
	mysqli_free_result($result2);  // 釋放佔用的記憶體
	require_once("myschool_close.inc");
?>
</br></br>   
</div>

<div  id="footer">version : 1.0</div>
</body>
</html>
