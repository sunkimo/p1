<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>login.php</title>
</head>
<body>
<?php

session_start();  // 啟用交談期

if (@$_SESSION["login_session"] == true ) 
    header("Location: main.php");


$username = "";  $password = "";
//檢查是否曾有輸入過非法字元，有則的話輸警告語 ==> "請勿輸入非法字元"
if (isset($_SESSION["error"]) && $_SESSION["error"]==true)
{	
		echo "<center><font color='red'>";
		echo "請勿輸入非法字元!<br/>";
		echo "</font></center>";
		unset($_SESSION["error"]);
}
// 取得表單欄位值
if ( isset($_POST["Username"]) )
   $username = $_POST["Username"];
if ( isset($_POST["Password"]) )
   $password = $_POST["Password"];

// 杜絕隱碼攻擊
//("/[\W]/")匹配非字母、数字、下划线。等价于 '[^A-Za-z0-9_]'。
//("/[\w]/")匹配字母、数字、下划线。等价于'[A-Za-z0-9_]'。
if(preg_match("/[\W]/",$username) || preg_match("/[\W]/",$password)) 
{
	$username = "";  $password = ""; 	//淨空$username和$password的值,以免往下傳至mysqli相關函數執行。
	$_SESSION["error"]=true;  
	header("Location: login.php");
}
if ($username != "" && $password != "") {
   
   if ( $username == "admin" && $password == "admin" ) {
      // 成功登入, 指定Session變數
	  $rows=mysqli_fetch_array($result,MYSQLI_ASSOC);
      $_SESSION["login_session"] = true;
	  $_SESSION["ss_username"] = $username;
	  $_SESSION["ss_password"] = $password;
	  
      header("Location: main.php");
   } else {  // 登入失敗
      echo "<center><font color='red'>";
      echo "使用者名稱或密碼錯誤!<br/>";
      echo "</font>";
      $_SESSION["login_session"] = false;
   }
   
}
?>
<form action="login.php" method="post">
<table align="center" bgcolor="#FFCC99">
 <tr><td><font size="2">使用者名稱:</font></td>
   <td><input type="text" name="Username" 
             size="15" maxlength="10" autofocus="autofocus" required />
   </td></tr>
 <tr><td><font size="2">使用者密碼:</font></td>
   <td><input type="password" name="Password"
              size="15" maxlength="10" required />
   </td></tr>
 <tr><td colspan="2" align="center">
   <input type="submit" value="登入網站"/>
   </td></tr> 
</table>
</form>
</body>
</html>