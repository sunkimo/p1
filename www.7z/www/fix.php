<?php

session_start();  // 啟用交談期
if (!isset($_SESSION["login_session"]) || @$_SESSION["login_session"] == false ) 
{
	echo '<center><font color="red">無權限!</font></center>';
    echo '<meta http-equiv=REFRESH CONTENT=2;url=login.php>';
	exit();
	//header("Location: login.php");
}

if ( isset($_GET["p_num"]) )
   $_SESSION["p_num"]= $_GET["p_num"];
else
{
	echo '<center><font color="red">未選定要修改的記錄</font></center>';
    echo '<meta http-equiv=REFRESH CONTENT=2;url=main.php>';
	exit();
	//header("Location: main.php");
	
}

?>

<?php
	require_once("myschool_open.inc");

	$sql = "SELECT * FROM people WHERE p_num='";									
	$sql.= $_SESSION["p_num"]."'"; 
	$result = mysqli_query($link, $sql);
	$total_records=mysqli_num_rows($result);  // 取得記錄數
	$rows = mysqli_fetch_array($result, MYSQLI_BOTH);
		
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
	<title>fix.php</title>
	<link rel=stylesheet type="text/css" href=style5.css>
	
</head>

<body>
<div id="header">
	<p><h1 class="title_top"> 通報系統 </h1></p>
</div>
<div id="nav">
	<table style="display:inline;float:left;">
	<tbody class="menu">
		<tr>
		<td>登入者：<?php echo $_SESSION["ss_username"] ?>&nbsp; &nbsp; &nbsp;</td>
		<td><a class="nav_a" href="main.php">[返回]</a>&nbsp;</td>
		</tr>
	</tbody>
	</table>
        
	<table style="display:inline;float:right;">
	<tbody class="menu">
		<tr><td><a class="nav_a" href="logout.php">[登出]</a>&nbsp;</td></tr>
	</tbody>
	</table>
</div>
 

<div id="content">
</br>


<form action="action.php" method="post">

<div align="center" display="inline">
<table align="center">
  <tr><td>編號:</td>
  <td><input readonly="readonly" type="text" size="5" maxlength="5" name="p_num" 
  value="<?php echo $rows["p_num"]; ?>" required />
  </td></tr>
  <tr><td>姓名:</td>
  <td><input type="text" size="10" maxlength="10" autofocus="autofocus" name="name" value="<?php echo $rows["name"]; ?>" required />
  </td></tr>
  
  <tr><td>身分證:</td>
  <td><input type="text" size="10" maxlength="10" name="id" value="<?php echo $rows["id"]; ?>" required/>
  </td></tr>
  
  <tr><td>住址:</td>
  <td><input type="text" size="60" maxlength="60" name="address" value="<?php echo $rows["address"]; ?>" required/>
  </td></tr>
  
  <tr><td>RFID號碼：</td>
  <td><input type="text" size="8" maxlength="8" name="rfid_no" value="<?php echo $rows["rfid_no"]; ?>" required/>
  </td></tr>
  
  <tr><td>通報狀態：</td>
  <td><input type="radio" value="1" name="state"<?php if($rows["state"]==true) echo "checked"; ?> />有
  <input type="radio" value="0" name="state" <?php if($rows["state"]==false) echo "checked"; ?> />無
  </td></tr>
  
  <tr><td>聯絡人:</td>
  <td><input type="text" size="10" maxlength="10" name="rname" value="<?php echo $rows["rname"]; ?>" required/>
  </td></tr>
  
  <tr><td>聯絡人市話:</td>
  <td><input type="text" size="10" maxlength="10" name="telephone" value="<?php echo $rows["telephone"]; ?>" required/>
  </td></tr>
  
  <tr><td>聯絡人電話:</td>
  <td><input type="text" size="10" maxlength="10" name="mphone" value="<?php echo $rows["mphone"]; ?>" required/>
  </td></tr>
  
  <tr><td>line token:</td>
  <td><input type="text" size="50" maxlength="50" name="rlinetoken" value="<?php echo $rows["rlinetoken"]; ?>" required/>
  </td></tr>
 
  
  
 

 
  
  
</table>
</div>
</br>
<input type="submit" name="update" value="確定"/>


</form>




</br>  
</div>

<div  id="footer"> version : 1.0 </div>
</body>
</html>
