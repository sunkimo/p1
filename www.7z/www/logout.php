﻿<?php 
    session_start();
    header("Content-Type:text/html; charset=utf-8");
    echo '已登出';
    session_destroy();
    echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
?>
